package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DAO;
import model.JavaBeans;

/**
 * Servlet implementation class Controller
 */
@WebServlet(urlPatterns = {"/Controller","/main","/inserir","/select","/update","/delete"})
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	DAO dao = new DAO();
	JavaBeans cliente = new JavaBeans();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//Teste e Conex�o
		//DAO dao = new DAO();
		//dao.testeConexao();
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")) {
			cliente(request, response);
		}else if (action.equals("/inserir")) {
			novoCliente(request,response);
		}else if (action.equals("/select")) {
			listarCliente(request,response);
		}else if (action.equals("/delete")) {
			excluirCliente(request,response);
		}else if (action.equals("/update")) {
		editarCliente(request,response);
		}else {
			response.sendRedirect("index.html");
		}
	}

	protected void cliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.sendRedirect("loja.jsp");
		//Receber dados da int�ncia JavaBeans
				ArrayList<JavaBeans> lista = dao.listarCliente();
				//teste
				/*for (int i = 0; i < lista.size(); i++) {
					System.out.println(lista.get(i).getIdcon());
					System.out.println(lista.get(i).getNome());
					System.out.println(lista.get(i).getFone());
					System.out.println(lista.get(i).getEmail());
					System.out.println(lista.get(i).getNumcard());
					System.out.println(lista.get(i).getAcomodacao());
				}*/
				//M�todo de importar os dados para visualiza��o
				request.setAttribute("cliente", lista);
				RequestDispatcher rd = request.getRequestDispatcher("loja.jsp");
				rd.forward(request, response);	

	}
	
	protected void novoCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getParameter("nome"));
		System.out.println(request.getParameter("ender"));
		System.out.println(request.getParameter("bairro"));
		System.out.println(request.getParameter("cidade"));
		System.out.println(request.getParameter("uf"));
		System.out.println(request.getParameter("fone"));
		System.out.println(request.getParameter("email"));
		System.out.println(request.getParameter("obsPath"));
		
		
		this.cliente.setNome(request.getParameter("nome"));
		this.cliente.setEnder(request.getParameter("ender"));
		this.cliente.setBairro(request.getParameter("bairro"));
		this.cliente.setCidade(request.getParameter("cidade"));
		this.cliente.setUf(request.getParameter("uf"));
		this.cliente.setFone(request.getParameter("fone"));
		this.cliente.setEmail(request.getParameter("email"));
		this.cliente.setObsPath(request.getParameter("obsPath"));
		
		
		dao.inserirCliente(cliente);
		
		
		response.sendRedirect("main");
		
	}
		protected void listarCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			//Recebe o par�metro idcli
			String idcli = request.getParameter("idcli");
			//Testa o envio do parametro
			System.out.println(idcli);
			//Configura o parametro no objeto
			this.cliente.setIdcli(idcli);
			//Selecionar o contato
			this.dao.selecionarCliente(cliente);
			//Teste
			/*System.out.println(cliente.getIdcli());
			 System.out.println(cliente.getNome());
			 System.out.println(cliente.getEnder());
			 System.out.println(cliente.getBairro());
			 System.out.println(cliente.getCidade());
			 System.out.println(cliente.getUf());
			 System.out.println(cliente.getFone());
			 System.out.println(cliente.getEmail());*/
			 
			request.setAttribute("idcli", cliente.getIdcli());
			request.setAttribute("nome", cliente.getNome());
			request.setAttribute("ender", cliente.getEnder());
			request.setAttribute("bairro", cliente.getBairro());
			request.setAttribute("cidade", cliente.getCidade());
			request.setAttribute("uf", cliente.getUf());
			request.setAttribute("fone", cliente.getFone());
			request.setAttribute("email", cliente.getEmail());
			RequestDispatcher rd = request.getRequestDispatcher("editar.jsp");
			rd.forward(request, response);
		}
		

	protected void editarCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.cliente.setIdcli(request.getParameter("idcli"));
		this.cliente.setNome(request.getParameter("nome"));
		this.cliente.setEnder(request.getParameter("ender"));
		this.cliente.setBairro(request.getParameter("bairro"));
		this.cliente.setCidade(request.getParameter("cidade"));
		this.cliente.setUf(request.getParameter("uf"));
		this.cliente.setFone(request.getParameter("fone"));
		this.cliente.setEmail(request.getParameter("email"));
		this.dao.alterarCliente(this.cliente);
		response.sendRedirect("main");
	}
		//Remover um contoto
	protected void excluirCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//recebimento do id 
	String idcli = request.getParameter("idcli");
	System.out.println(idcli);
	//setar a varivel idcli JavaBeans
	cliente.setIdcli(idcli);
	//executar o metodo deletarcliente DAO passando o objeto
	dao.deletarCliente(cliente);
	
	response.sendRedirect("main");
	
	}
	
	
	
	
	
	
	}

