package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
	// Parametros de conex�o
	private String driver="com.mysql.cj.jdbc.Driver";
	private String url="jdbc:mysql://127.0.0.1:3306/dbloja?useTimezone=true&serverTimezone=UTC";
	private String user="root";
	private String password="";
	
	// Conex�o
	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			return con;
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
	
	public void inserirCliente(JavaBeans cliente) {
		String SQLinsert = "insert into cliente(nome,ender,bairro,cidade,uf,fone,email,obs) values (?,?,?,?,?,?,?,?);";
		
			try {
				Connection con = conectar();
				
				// Preparar a Query
				PreparedStatement pst = con.prepareStatement(SQLinsert);
				
				// Substituir as ?
				pst.setString(1, cliente.getNome());
				pst.setString(2, cliente.getEnder());
				pst.setString(3, cliente.getBairro());
				pst.setString(4, cliente.getCidade());
				pst.setString(5, cliente.getUf());
				pst.setString(6, cliente.getFone());
				pst.setString(7, cliente.getEmail());
				pst.setString(8, cliente.getObsPath());
				
				//Executar SQL
				pst.executeUpdate();
				
				//Encerrar a concex�ocon.close();
				con.close();
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
	}
	
	
	//CRUD READ
		public ArrayList<JavaBeans> listarCliente(){
			ArrayList<JavaBeans> cliente = new ArrayList<JavaBeans>();
			String sqlRead = "select * from cliente order by nome";
			
			try {
				Connection con = conectar();
				//Preparar a query
				PreparedStatement pst = con.prepareStatement(sqlRead);
				ResultSet rs = pst.executeQuery();
				while (rs.next() ) {
					String idcli = rs.getString(1);
					String nome = rs.getString(2);
					String ender = rs.getString(3);
					String bairro = rs.getString(4);
					String cidade = rs.getString(5);
					String uf = rs.getString(6);
					String fone = rs.getString(7);
					String email = rs.getString(8);
					
					
					
					//Enviando a Matriz
					cliente.add(new JavaBeans(idcli,nome,ender,bairro,cidade,uf,fone,email));
				}
				con.close();
				return cliente;
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
				return null;
			}
		}
		
		/* CRUD Select */
		public void selecionarCliente(JavaBeans cliente) {
			String sqlSelect = "select * from cliente where idcli=?";
			try {
				Connection con = conectar();
				//Preparar a query
				PreparedStatement pst = con.prepareStatement(sqlSelect);
				// Substituir os par�mentros 
				pst.setString(1, cliente.getIdcli());
				//Executar SQL
				ResultSet rs = pst.executeQuery();
				//Enquato houver pacientes
				while (rs.next()) {
					// Recebendo do banco
					// System.out.prinln(rs.getNString(2));
					cliente.setIdcli(rs.getString(1));
					cliente.setNome(rs.getString(2));
					cliente.setEnder(rs.getString(3));
					cliente.setBairro(rs.getString(4));
					cliente.setCidade(rs.getString(5));
					cliente.setUf(rs.getString(6));
					cliente.setFone(rs.getString(7));
					cliente.setEmail(rs.getString(8));
					
				}
				//encerrar conex�o
				con.close();
				}catch (Exception e) {
					// TODO: handle exception
					System.out.println(e);
			}
		}
		
		/*
		public void testeConexao() {
			try {
				Connection con=conectar();
				System.out.println(con);
				con.close();			
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
				
			}
		}*/
		
		/* CRUD Update */
		public void alterarCliente(JavaBeans cliente) {
			String sqlUpdate = "update cliente set nome=?,ender=?,bairro=?,cidade=?,uf=?,fone=?,email=? where idcli=?";
			try {
				Connection con = conectar();
				//Preparar a query
				PreparedStatement pst = con.prepareStatement(sqlUpdate);
				// Substituir os par�mentros 
					pst.setString(1, cliente.getNome());
					pst.setString(2, cliente.getEnder());
					pst.setString(3, cliente.getBairro());
					pst.setString(4, cliente.getCidade());
					pst.setString(5, cliente.getUf());
					pst.setString(6, cliente.getFone());
					pst.setString(7, cliente.getEmail());
					pst.setString(8, cliente.getIdcli());
			
				//executar SQL
			pst.executeUpdate();
				// encerrar conex�o
				con.close();
		} catch (Exception e) {
					// TODO: handle exception
					System.out.println(e);
			}
			
		}
		
		//CRUD DELETE
		public void deletarCliente(JavaBeans cliente) {
			String delete ="delete from cliente where idcli=?";
			try {
				Connection con = conectar();
				PreparedStatement pst = con.prepareStatement(delete);
				pst.setString(1, cliente.getIdcli());
				pst.executeUpdate();
				con.close();
			}catch (Exception e) {
				System.out.println(e);
			}
		}
	}

