package model;

public class JavaBeans {
	private String idcli;
	private String nome;
	private String ender;
	private String bairro;
	private String cidade;
	private String uf;
	private String fone;
	private String email;
	private String obsPath;
	
	
	public JavaBeans() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public JavaBeans(String idcli, String nome,String ender,String bairro,String cidade,String uf, String fone, String email, String obsPath) {
		super();
		this.idcli = idcli;
		this.nome = nome;
		this.ender = ender;
		this.bairro = bairro;
		this.cidade = cidade;
		this.uf = uf;
		this.fone = fone;
		this.email = email;
		this.obsPath= obsPath;
	}

	public JavaBeans(String idcli, String nome,String ender,String bairro,String cidade,String uf, String fone, String email) {
		super();
		this.idcli = idcli;
		this.nome = nome;
		this.ender = ender;
		this.bairro = bairro;
		this.cidade = cidade;
		this.uf = uf;
		this.fone = fone;
		this.email = email;
		
	}
		
	
	public String getIdcli() {
		return idcli;
	}
	public void setIdcli(String idcli) {
		this.idcli = idcli;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEnder() {
		return ender;
	}
	public void setEnder(String ender) {
		this.ender = ender;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getObsPath() {
		return "LOAD_FILE(" + this.obsPath + ")";
	}

	public void setObsPath(String obsPath) {
		this.obsPath = obsPath;
	}
	
	
	}
	
	
	
	
