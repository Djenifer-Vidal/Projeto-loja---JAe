/**
 * 
 */
 function validar(){
	let nome = frmCliente.nome.value;
	let fone = frmCliente.fone.value;
	let ender = frmCliente.ender.value;
	let bairro = frmCliente.bairro.value;
	let cidade = frmCliente.cidade.value;
	let uf = frmCliente.uf.value;
	
	if (nome === ""){
		alert("Campo nome Obrigatório");
		frmCliente.nome.focus();
	}
	else 
		if (fone === "") {
			alert("Campo fone Obrigatório");
			frmCliente.fone.focus();
		}
		else 
		if (ender === "") {
			alert("Campo endereço Obrigatório");
			frmCliente.ender.focus();
		}
		else 
		if (bairro === "") {
			alert("Campo bairro Obrigatório");
			frmCliente.bairro.focus();
		}
		else 
		if (cidade === "") {
			alert("Campo cidade Obrigatório");
			frmCliente.cidade.focus();
		}
		else 
		if (uf === "") {
			alert("Campo uf Obrigatório");
			frmCliente.uf.focus();
		}
		
	else
		document.forms["frmCliente"].submit();
}/**
 * 
 */