/**
 * 
 */
function confirmar(idcli){
	let resposta = confirm("Confirmar a exlcusão deste contato?")
	if (resposta === true){
		//alert(idcli)
		window.location.href="delete?idcli=" + idcli
	}
}